module.exports = {
  tokens: "8518906122:AAGySAYRxTf15pG513pp438VhHPYxmWNaVQ",  // Ubah Jadi Token Bot Mu !!!
  owner: "7300602830", // Ubah Jadi Id Mu !!!
  port: "22", // Ubah Jadi Port Panel Mu !!!
  ipvps: "158.69.251.105" // Ubah Jadi Ip Vps Mu !!!
};